import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { base_url } from 'src/environments/environment';
import { ToolsService } from './tools.service';

@Injectable({
  providedIn: 'root'
})
export class JoueurService {

  constructor(private http : HttpClient, private toolsServ : ToolsService) { }
  getAll () {
    return this.http.get(base_url + 'joueur');
  }

  getByPseudo (keyword) {
    return this.http.get(base_url + 'joueur?pseudo=' + keyword);
  }

  create (input) {
    const options = this.toolsServ.formOption(); // headers
    if (input.age <= 100)
      return this.http.post(base_url + 'joueur', input, options);
    else
      throw new Error('Some error');
  }

  updateById (idjoueur, input) {
    const options = this.toolsServ.formOption(); // headers
    return this.http.put(base_url + 'joueur/' + idjoueur, input, options);
  }

  deleteById(idjoueur) {
    return this.http.delete(base_url + 'joueur/' + idjoueur);
  }

}
