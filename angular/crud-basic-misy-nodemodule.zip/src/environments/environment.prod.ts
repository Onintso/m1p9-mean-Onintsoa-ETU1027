export const environment = {
  production: true
};

export const base_url = 'http://localhost/basic-crud/';